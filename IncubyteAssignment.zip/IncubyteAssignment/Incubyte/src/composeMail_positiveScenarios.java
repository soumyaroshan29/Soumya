import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class composeMail_positiveScenarios {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Soumya_Rajagopal\\Desktop\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.gmail.com");	
		driver.manage().window().maximize();
		System.out.println(driver.getTitle());
		driver.findElement(By.id("identifierId")).sendKeys("soumyaIncubyte@gmail.com"); // Username
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"identifierNext\"]/div/button")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"password\"]/div[1]/div/div[1]/input")).sendKeys("test*678"); // Password
		driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[2]/div/c-wiz/div/div[2]/div/div[2]/div/div[1]/div/div/button/span")).click();
		Thread.sleep(5000);
		
		WebElement composeButton = driver.findElement(By.xpath("/html/body/div[7]/div[3]/div/div[2]/div[1]/div[1]/div/div")); // Compose Mail Button 
		if (composeButton.isDisplayed())
		{
			System.out.println("Compose Mail Button is present");

		}
		
		composeButton.click();		
		Thread.sleep(5000);
		
		WebElement RecipientTo = driver.findElement(By.cssSelector("input[class^='agP']"));  // To recipient
		if (RecipientTo.isDisplayed())
		{
			System.out.println("User is able to enter email address in To Recipient");
		}
		
		else
		{
			System.out.println("User is unable to enter email address in To");
		}
		
		
	   RecipientTo.sendKeys("soumyaIncubyte@gmail.com");	
	   driver.findElement(By.name("subjectbox")).sendKeys("Incubyte Deliverables:1");
	   Thread.sleep(5000);
       driver.findElement(By.xpath("(//div[contains(@class,'aaA aaB')])[4]")).click();
	   driver.findElement(By.xpath("(//div[contains(@class,'aaA aaB')])[5]")).click();
	   driver.findElement(By.xpath("(//div[contains(@class,'aaA aaB')])[6]")).click();
	   
	   
		 driver.findElement(By.cssSelector(".Am.Al.editable.LW-avf.tS-tW")).sendKeys("Automation QA test for Incubyte");
		 
		

		 WebElement AttachFilesBtn = driver.findElement(By.cssSelector(".a1.aaA.aMZ"));
		 if(AttachFilesBtn.isDisplayed())
		 {
				System.out.println("Email Attachment is possible");

		}
		 
		 
		 driver.findElement(By.xpath("//div[text()='Send']")).click();
		 
		 Thread.sleep(2000);
		  WebElement MessageSent = driver.findElement(By.xpath("//div[@role='alert']//div[@class='vh']"));
		 if(MessageSent.isDisplayed())
			{
				System.out.println("Mail sent successfully");

			}
		 
		 Thread.sleep(2000);
		//driver.close();		
	}
}

