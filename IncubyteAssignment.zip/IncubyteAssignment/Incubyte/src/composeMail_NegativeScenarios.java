import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class composeMail_NegativeScenarios {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Soumya_Rajagopal\\Desktop\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.gmail.com");	
		driver.manage().window().maximize();
		System.out.println(driver.getTitle());
		driver.findElement(By.id("identifierId")).sendKeys("soumyaIncubyte@gmail.com");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"identifierNext\"]/div/button")).click();
		Thread.sleep(5000);
		driver.findElement(By.name("Passwd")).sendKeys("test*678");
		driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[2]/div/c-wiz/div/div[2]/div/div[2]/div/div[1]/div/div/button/span")).click();
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("/html/body/div[7]/div[3]/div/div[2]/div[1]/div[1]/div/div")).click();
		Thread.sleep(5000);
		
		// Negative scenario to check warning message when wrong email address is entered
		WebElement RecipientTo = driver.findElement(By.cssSelector("input[class^='agP']"));
		RecipientTo.sendKeys("abc");
		
		driver.findElement(By.xpath("//div[text()='Send']")).click();
		
		Alert alert = driver.switchTo().alert();
		   String alertMessage= driver.switchTo().alert().getText();
		   System.out.println(alertMessage);	
	       Thread.sleep(5000);       
	       alert.accept();
	       
	       Thread.sleep(5000); 
	       WebElement ErrMsg1 = driver.findElement(By.xpath("/html/body/div[40]/div[2]"));
	       if (ErrMsg1.isDisplayed())
	       {
				System.out.println("Enter proper email address");
			}
	       Thread.sleep(5000);
	       driver.findElement(By.name("ok")).click();
	       
	    // Negative scenario to check warning message when mail is sent without subject or body
	       RecipientTo.clear();
	       RecipientTo.sendKeys("soumyar87@gmail.com");
	       Thread.sleep(5000);
	       driver.findElement(By.xpath("//div[text()='Send']")).click();
	       Alert alert1 = driver.switchTo().alert();
		   String alertMessage1= driver.switchTo().alert().getText();
		   System.out.println(alertMessage1);	
	       Thread.sleep(5000);       
	       alert1.dismiss();
	       
	    // Negative scenario to check warning message when mail is sent without subject or body
	       RecipientTo.clear();
	       Thread.sleep(5000);
	       driver.findElement(By.name("subjectbox")).sendKeys("Incubyte Deliverables:1");
	       driver.findElement(By.cssSelector(".Am.Al.editable.LW-avf.tS-tW")).sendKeys("Automation QA test for Incubyte");
	       driver.findElement(By.xpath("//div[text()='Send']")).click();
	       
	      
	       Thread.sleep(5000);
	       WebElement ErrorMsg1 = driver.findElement(By.xpath("/html/body/div[40]/div[2]"));
	       Thread.sleep(5000);
			if (ErrorMsg1.isDisplayed())
			{
				System.out.println("Please specify at least one recipient.");
			}
			
			driver.findElement(By.xpath("//button[@name='ok']")).click();      
	       

	       
	   //    driver.close();	
	       
	       
	       
		
		

	}

}
